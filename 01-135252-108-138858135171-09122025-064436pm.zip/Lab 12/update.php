<!DOCTYPE html>
<html>
<head>
    <title>Update Email</title>
</head>
<body>

<h2>Update Student Email</h2>

<form action="update.php" method="POST">
    <input type="number" name="id" placeholder="Enter ID" required>
    <input type="email" name="email" placeholder="Enter new email" required>
    <button type="submit">Update</button>
</form>

</body>
</html>
