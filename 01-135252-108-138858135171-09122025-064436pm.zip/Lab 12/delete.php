<!DOCTYPE html>
<html>
<head>
    <title>Delete Record</title>
</head>
<body>

<h2>Delete User Record</h2>

<form action="delete.php" method="POST">
    <input type="number" name="id" placeholder="Enter ID to delete" required>
    <button type="submit">Delete</button>
</form>

</body>
</html>
