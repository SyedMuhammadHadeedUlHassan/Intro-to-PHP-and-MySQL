<?php
try {
    $conn = mysqli_connect("localhost", "root", "", "studentdb");

    if (!$conn) {
        throw new Exception("Connection failed: " . mysqli_connect_error());
    }

    echo "DB connected succesfully by Hadeed Shah";

} catch (Exception $e) {
    echo $e->getMessage();
}
?>