<?php
include "dbTask9.php";

$result = mysqli_query($conn, "SELECT * FROM student");

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Table</title>
    <style>
        table { width: 70%; border-collapse: collapse; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background: #f2f2f2; }
        a { color: red; text-decoration: none; }
    </style>
</head>
<body>

<h2>Student Records</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Age</th>
        <th>Department</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['name']; ?></td>
            <td><?= $row['email']; ?></td>
            <td><?= $row['age']; ?></td>
            <td><?= $row['department']; ?></td>
            <td>
                <a href="delete.php?id=<?= $row['id']; ?>" onclick="return confirm('Delete this record?');">Delete</a>
            </td>
        </tr>
    <?php } ?>

</table>

<br>
<a href="insert_form.html">Add New Student</a>

</body>
</html>
s