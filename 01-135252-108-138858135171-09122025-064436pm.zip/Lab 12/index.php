<?php
$name = "Syed Muhammad hadeed ul hassan";
echo "<h1>Welcome, $name!</h1>";
$course="BS-IT";
echo "<h1>$course!</h1>";
?>