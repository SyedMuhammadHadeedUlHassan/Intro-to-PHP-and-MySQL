<?php
include "db.php";

$name  = $_POST['name'];
$email = $_POST['email'];
$age   = $_POST['age'];

$query = "INSERT INTO user (name, email, age) VALUES ('$name', '$email', '$age')";

if (mysqli_query($conn, $query)) {
    echo ", Hello  $name, your data has been stored.";
} else {
    echo "Error inserting data!";
}

mysqli_close($conn);
?>
